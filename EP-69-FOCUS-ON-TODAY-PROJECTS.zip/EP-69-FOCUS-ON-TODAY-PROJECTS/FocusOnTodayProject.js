const checkBoxList = document.querySelectorAll('.custome-checkbox');
const inputFields = document.querySelectorAll('.goal-input');
const errorLabel = document.querySelector('.error-label')

const progressBar = document.querySelector('.progress-bar')
const progressValue = document.querySelector('.progress-value');
const progressLabel = document.querySelector('.progress-label');

const allQuotes = [
  'Raise th bar by completing your goals!',
  'Well begun done!',
  'Just s step away, keep going!',
  'Whoa! You just completed all the goals, time for chill :D'
]

// const allGoals = JSON.parse(localStorage.getItem('allGoals')) || {
//   first : {
//     name: '',
//     completed : false,
//   },
//   second: {
//     name : '',
//     completed : false,
//   },
//   third : {
//     name : '',
//     completed : false,
//   },

// }

const allGoals = JSON.parse(localStorage.getItem('allGoals')) || {};

  function countAllGoals(){
  let completedGoalsCoun = Object.values(allGoals).filter((goal) =>goal.completed).length
  progressValue.style.width = `${(completedGoalsCoun / inputFields.length) * 100}%`
  progressValue.firstElementChild.innerText = `${completedGoalsCoun}/${inputFields.length} completed`
  progressLabel.innerText = allQuotes[completedGoalsCoun];
  }

checkBoxList.forEach((checkbox) =>{
  checkbox.addEventListener('click' , (e)=>{
    const allGoalsAdded = [...inputFields].every(function (input) {
      //console.log(input.value);
      return input.value
    })

    if(allGoalsAdded) {
      checkbox.parentElement.classList.toggle('completed');
      progressValue.style.width = '33.33%';
      // errorLabel.parentElement.classList.remove('show-error');
      const inputId = checkbox.nextElementSibling.id;
      allGoals[inputId].completed = !allGoals[inputId].completed
      // completedGoalsCoun = Object.values(allGoals).filter((goal) =>goal.completed).length
      // progressValue.style.width = `${(completedGoalsCoun / 3) * 100}%`;
      countAllGoals();
      localStorage.setItem('allGoals',JSON.stringify(allGoals));
    }
    else{
      progressBar.classList.add('show-error');
      // errorLabel.parentElement.classList.add('show-error');
    }
  })
})

inputFields.forEach((input) =>{

  if(allGoals[input.id]){
    input.value = allGoals[input.id].name;

    if(allGoals[input.id].completed){
    input.parentElement.classList.add('completed');
  }
  }


  input.addEventListener('focus', ()=>{
    progressBar.classList.remove('show-error');
  })


  input.addEventListener('input', (e) =>{

    if(allGoals[input.id]  && allGoals[input.id].completed){
      input.value = allGoals[input.id].name
      return
    }

    // allGoals[input.id]  = {
    //   name : input.value,
    // }

    if(allGoals[input.id]){
      allGoals[input.id].name = input.value;
    }
    else{
      allGoals[input.id] = {
        name : input.value,
        completed : false,
      }
    }

    localStorage.setItem('allGoals', JSON.stringify(allGoals));
    // allGoals.id. = e.target.value;
  })               
})

















































// allCheckBoxList2.forEach((checkbox) => {
//   checkbox.addEventListener('click',(e) =>{
//     checkbox.parentElement.classList.toggle('completed')
//   })
// })


// const allInputs = document.querySelectorAll('.goal-input');

// let count = 0;

// allInputs.forEach((inputs) =>{
//   inputs.addEventListener('focus', (e)=>{
//       count++;
//   })
// })



// if(count===0){
//   const errorLabel = document.querySelector('.error-label');
//   errorLabel.classList.add('show-error');
// }

// let count1 = 0;

// allInputs.forEach((inputs1) =>{
//   inputs1.addEventListener('input', (e) =>{
//     if(e.target.value.length === 1){
//        count1++;
//     }
//   })
//   if(count1 === 3){
//   const errorLabel = document.querySelector('.error-label');
//   errorLabel.classList.add('delete-error');
//   }
// })

//   console.log(count1);

  




